package com.conamobile.sosapp.constants;

public class IntentConstant
{
    public static final String LOCK_SCREEN_ACTION_INTENT = "LOCK_SCREEN_ACTION_INTENT"; //check with
}
