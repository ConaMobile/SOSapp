package com.conamobile.sosapp.constants

object Constant {
    const val DATE_FORMAT_STR = "yyyy-MM-dd'T'HH:mm:ssZZZZZ"
}