package com.conamobile.sosapp.constants;

public class KeyConstant
{
    public static final String UNLOCK_STR = "unlock";
    public static final String PHONE_DATA_STR = "PHONE_DATA";
    public static final String VOLUME_LOCK_ENABLE_STR = "VOLUME_LOCK_ENABLE";
    public static final String REQUEST_FOR_STR = "REQUEST_FOR";
    public static final String FLOATING_LOCK_STR = "floating_lock";
}
